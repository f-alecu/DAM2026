package com.example.seminar1dam;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.Random;

public class MainActivity extends AppCompatActivity {

    boolean app_on = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        TextView tv = (TextView) findViewById(R.id.textView);
        tv.setTextColor(Color.GRAY);

        ImageView iv = (ImageView) findViewById(R.id.imageView);
        iv.setImageResource(R.drawable.off);

        Switch sw = (Switch) findViewById(R.id.switch1);
        sw.setVisibility(View.INVISIBLE);

        Button bt = (Button) findViewById(R.id.button);
        bt.setVisibility(View.INVISIBLE);


    }

    public void doImageClick(View view) {

        if (app_on) {
            TextView tv = (TextView) findViewById(R.id.textView);
            tv.setTextColor(Color.GRAY);

            ImageView iv = (ImageView) findViewById(R.id.imageView);
            iv.setImageResource(R.drawable.off);

            Switch sw = (Switch) findViewById(R.id.switch1);
            sw.setVisibility(View.INVISIBLE);

            Button bt = (Button) findViewById(R.id.button);
            bt.setVisibility(View.INVISIBLE);

            app_on = false;

            Toast.makeText(this, "App is now OFF!", Toast.LENGTH_SHORT).show();
        }
        else {
            TextView tv = (TextView) findViewById(R.id.textView);
            tv.setTextColor(Color.RED);

            ImageView iv = (ImageView) findViewById(R.id.imageView);
            iv.setImageResource(R.drawable.on);

            Switch sw = (Switch) findViewById(R.id.switch1);
            sw.setVisibility(View.VISIBLE);

            Button bt = (Button) findViewById(R.id.button);
            if (sw.isChecked())
                bt.setVisibility(View.VISIBLE);
            else
                bt.setVisibility(View.INVISIBLE);

            app_on = true;

            Toast.makeText(this, "App is now ON!", Toast.LENGTH_SHORT).show();
        }

    }

    public void doSwitchClick(View view) {
        Switch sw = (Switch) findViewById(R.id.switch1);
        Button bt = (Button) findViewById(R.id.button);

        if (sw.isChecked())
            bt.setVisibility(View.VISIBLE);
        else
            bt.setVisibility(View.INVISIBLE);
    }

    public void doButtonClick(View view) {
        Random r = new Random();
        int i = r.nextInt(1000);

        Toast.makeText(this, "Am generat " + i, Toast.LENGTH_SHORT).show();

        // deschidem activitatea 2
        Intent newActivity = new Intent(this, MainActivity2.class);
        newActivity.putExtra(Intent.EXTRA_TEXT, "Activitate #2 ::: " + i);
        startActivity(newActivity);
    }
}