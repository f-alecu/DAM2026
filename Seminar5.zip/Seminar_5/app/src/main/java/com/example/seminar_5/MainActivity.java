package com.example.seminar_5;

import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity implements DialogInterface.OnDismissListener {

    String AppCode;

    Boolean WrongAppCode = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);

        SharedPreferences sp = getSharedPreferences("APP_CODE", MODE_PRIVATE);
        AppCode = sp.getString("app_code", "");

        AlertDialog.Builder ad = new AlertDialog.Builder(this);
        if (AppCode.isEmpty())
            ad.setTitle("Definiti codul aplicatiei");
        else
            ad.setTitle("Introduceti codul aplicatiei");
        ad.setCancelable(false);
        EditText et = new EditText(this);
        et.setHint("Introduceti codul corect");
        et.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        ad.setView(et);

        ad.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

                WrongAppCode = false;

                if (AppCode.isEmpty()) {
                    AppCode = et.getText().toString();
                    SharedPreferences.Editor editor = sp.edit();
                    editor.putString("app_code", AppCode);
                    editor.apply();
                }

                if (!AppCode.equals(et.getText().toString())){
                    et.setText("");
                    et.setHint("Introduceti codul corect");
                    WrongAppCode = true;
                }

            }
        });

        ad.setNegativeButton("Renunt", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                finish();
                System.exit(0);
            }
        });

        ad.setOnDismissListener(this);
        ad.show();


    }

    @Override
    public void onDismiss(DialogInterface dialog) {

        if (WrongAppCode) {
            ((AlertDialog) dialog).show();
            return;
        }

        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        TextView tv = (TextView)findViewById(R.id.textView);
        tv.setText(AppCode);
    }

    public void doAppCodeReset(View view) {
        SharedPreferences sp = getSharedPreferences("APP_CODE", MODE_PRIVATE);
        SharedPreferences.Editor editor = sp.edit();
        editor.putString("app_code", "");
        editor.apply();
    }
}