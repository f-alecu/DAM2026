package com.example.seminar_6;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity2 extends AppCompatActivity {

    boolean edit_mode = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main2);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        Intent intent = getIntent();
        if (intent.hasExtra("editAuto")){

            Auto a = (Auto)intent.getSerializableExtra("editAuto");
            EditText etMarca = (EditText)findViewById(R.id.etMarca);
            EditText etConsum = (EditText)findViewById(R.id.etConsum);

            etMarca.setText(a.Marca);
            etConsum.setText(String.valueOf(a.Consum));

            edit_mode = true;
        }

    }

    public void doSave(View view) {
        EditText etMarca = (EditText)findViewById(R.id.etMarca);
        EditText etConsum = (EditText)findViewById(R.id.etConsum);

        if (etMarca.getText().toString().isEmpty() ||
        etConsum.getText().toString().isEmpty()) {
            Toast.makeText(this, "Marca/Consumul nespecificat(e)", Toast.LENGTH_SHORT).show();
            return;
        }
        if (Double.parseDouble(etConsum.getText().toString()) > 20){
            Toast.makeText(this, "Consumul trebuie sa fie de cel mult 20!", Toast.LENGTH_SHORT).show();
            return;
        }

        Auto a = new Auto();
        a.Marca = etMarca.getText().toString();
        a.Consum = Double.parseDouble(etConsum.getText().toString());

        Intent intent = getIntent();

        if (edit_mode)
            intent.putExtra("editAuto", a);
        else
            intent.putExtra("addAuto", a);

        setResult(RESULT_OK, intent);

        finish();
    }

    public void doCancel(View view) {
        Intent intent = getIntent();
        setResult(RESULT_CANCELED, intent);
        finish();
    }
}