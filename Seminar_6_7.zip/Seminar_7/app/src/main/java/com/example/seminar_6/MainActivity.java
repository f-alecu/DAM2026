package com.example.seminar_6;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Random;

public class MainActivity extends AppCompatActivity implements AdapterView.OnItemLongClickListener {

    ArrayList<Auto> listaAuto = new ArrayList<>();
    ListView listaEcran;

    int REQUEST_ADD = 111;
    int REQUEST_EDIT = 222;

    int edit_position;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        Random rnd = new Random();
        for(int i=0; i< 10; i++){
            Auto a = new Auto();
            a.Marca = "Marca" + rnd.nextInt(1000);
            a.Consum = rnd.nextInt(100) / 5.0;

            listaAuto.add(a);
        }

        Collections.sort(listaAuto, new Comparator<Auto>() {
            @Override
            public int compare(Auto o1, Auto o2) {
                if (o1.Consum < o2.Consum)
                    return 1;
                else if (o1.Consum > o2.Consum)
                    return -1;
                else
                    return 0;
            }
        });

        listaEcran = (ListView) findViewById(R.id.listView);
        listaEcran.setOnItemLongClickListener(this);

        ArrayAdapter<Auto> adaptor = new ArrayAdapter<>(this, androidx.appcompat.R.layout.support_simple_spinner_dropdown_item, listaAuto);
        listaEcran.setAdapter(adaptor);

    }

    public void doAdd(View view) {
        Intent A2 = new Intent(this, MainActivity2.class);
        //startActivity(A2);
        startActivityForResult(A2, REQUEST_ADD);
    }

    @Override
    public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {

        Intent A2 = new Intent(this, MainActivity2.class);
        A2.putExtra("editAuto", listaAuto.get(position));
        //startActivity(A2);
        startActivityForResult(A2, REQUEST_EDIT);

        edit_position = position;

        return false;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        // cancel
        if (resultCode == RESULT_CANCELED) {
            if (requestCode == REQUEST_ADD)
                Toast.makeText(this, "Adaugare - Utilizatorul a renuntat!", Toast.LENGTH_SHORT).show();
            if (requestCode == REQUEST_EDIT)
                Toast.makeText(this, "Editare - Utilizatorul a renuntat!", Toast.LENGTH_SHORT).show();
        }

        // add
        if (requestCode == REQUEST_ADD && resultCode == RESULT_OK && data != null){
            Auto a = (Auto) data.getSerializableExtra("addAuto");
            Log.i("###auto", a.toString());

            listaAuto.add(a);

            ArrayAdapter<Auto> adaptor = (ArrayAdapter<Auto>)listaEcran.getAdapter();

            Collections.sort(listaAuto, new Comparator<Auto>() {
                @Override
                public int compare(Auto o1, Auto o2) {
                    if (o1.Consum < o2.Consum)
                        return 1;
                    else if (o1.Consum > o2.Consum)
                        return -1;
                    else
                        return 0;
                }
            });

            adaptor.notifyDataSetChanged();

        }

        // edit
        if (requestCode == REQUEST_EDIT && resultCode == RESULT_OK && data != null){
            Auto a = (Auto) data.getSerializableExtra("editAuto");
            Log.w("###auto", a.toString());

            listaAuto.get(edit_position).Marca = a.Marca;
            listaAuto.get(edit_position).Consum = a.Consum;

            ArrayAdapter<Auto> adaptor = (ArrayAdapter<Auto>) listaEcran.getAdapter();

            Collections.sort(listaAuto, new Comparator<Auto>() {
                @Override
                public int compare(Auto o1, Auto o2) {
                    if (o1.Consum < o2.Consum)
                        return 1;
                    else if (o1.Consum > o2.Consum)
                        return -1;
                    else
                        return 0;
                }
            });

            adaptor.notifyDataSetChanged();
        }
    }
}











