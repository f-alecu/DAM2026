package com.example.seminar_6;

import java.io.Serializable;

public class Auto implements Serializable {
    String Marca;
    double Consum;

    public Auto() {
        Marca = "";
        Consum = 0;
    }

    public Auto(String marca, double consum) {
        Marca = marca;
        Consum = consum;
    }

    @Override
    public String toString() {
        return "Auto {" +
                "Marca='" + Marca + '\'' +
                ", Consum=" + Consum +
                '}';
    }
}
